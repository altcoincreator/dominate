#!/bin/bash
# create multiresolution windows icon
ICON_SRC=../../src/qt/res/icons/dominate.png
ICON_DST=../../src/qt/res/icons/dominate.ico
convert ${ICON_SRC} -resize 16x16 dominate-16.png
convert ${ICON_SRC} -resize 32x32 dominate-32.png
convert ${ICON_SRC} -resize 48x48 dominate-48.png
convert dominate-48.png dominate-32.png dominate-16.png ${ICON_DST}

