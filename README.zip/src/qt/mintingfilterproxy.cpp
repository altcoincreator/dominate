#include "mintingfilterproxy.h"

MintingFilterProxy::MintingFilterProxy(QObject * parent) :
    QSortFilterProxyModel(parent)
{

}
