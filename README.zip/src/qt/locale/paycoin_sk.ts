<TS language="sk" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    </context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Address Book</source>
        <translation>Adresár</translation>
    </message>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Dvojklikom editovať adresu alebo popis</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Vytvoriť novú adresu</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopírovať práve zvolenú adresu do systémového klipbordu</translation>
    </message>
    <message>
        <source>Show &amp;QR Code</source>
        <translation>Zobraz &amp;QR Kód</translation>
    </message>
    <message>
        <source>Sign a message to prove you own this address</source>
        <translation>Podpísať správu a dokázať že vlastníte túto adresu</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Podpísať Správu</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Zmazať práve zvolená adresu zo zoznamu. Len adresy pre odosielanie sa dajú zmazať.</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Zmazať</translation>
    </message>
    <message>
        <source>Export Address Book Data</source>
        <translation>Exportovať dáta z adresára</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Čiarkou oddelený súbor (*.csv)</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Chyba exportu.</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Nedalo sa zapisovať do súboru %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Popis</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(bez popisu)</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Zadajte heslo</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nové heslo</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Zopakujte nové heslo</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Zadajte nové heslo k peňaženke.&lt;br/&gt;Prosím použite heslo s dĺžkou aspon &lt;b&gt;10 alebo viac náhodných znakov&lt;/b&gt;, alebo &lt;b&gt;8 alebo viac slov&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Zašifrovať peňaženku</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Táto operácia potrebuje heslo k vašej peňaženke aby ju mohla dešifrovať.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Odomknúť peňaženku</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Táto operácia potrebuje heslo k vašej peňaženke na dešifrovanie peňaženky.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Dešifrovať peňaženku</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Zmena hesla</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Potvrďte šifrovanie peňaženky</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Peňaženka zašifrovaná</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on.</source>
        <translation>Varovanie: Caps Lock je zapnutý</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Šifrovanie peňaženky zlyhalo</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Šifrovanie peňaženky zlyhalo kôli internej chybe. Vaša peňaženka nebola zašifrovaná.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Zadané heslá nesúhlasia.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Odomykanie peňaženky zlyhalo</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Zadané heslo pre dešifrovanie peňaženky bolo nesprávne.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Zlyhalo šifrovanie peňaženky.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Heslo k peňaženke bolo úspešne zmenené.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Suma:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Suma</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dátum</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potvrdené</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopírovať adresu</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopírovať popis</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopírovať sumu</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(bez popisu)</translation>
    </message>
    </context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Zobrazovať hodnoty v jednotkách:</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Upraviť adresu</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Popis</translation>
    </message>
    <message>
        <source>The label associated with this address book entry</source>
        <translation>Popis priradený k tomuto záznamu v adresári</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adresa</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Nová adresa pre prijímanie</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Nová adresa pre odoslanie</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Upraviť prijímacie adresy</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Upraviť odosielaciu adresu</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Vložená adresa "%1" sa už nachádza v adresári.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Nepodarilo sa odomknúť peňaženku.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Generovanie nového kľúča zlyhalo.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    </context>
<context>
    <name>MainOptionsPage</name>
    </context>
<context>
    <name>MintingTableModel</name>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    </context>
<context>
    <name>MintingView</name>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Čiarkou oddelovaný súbor (*.csv)</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Chyba exportu</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Nedalo sa zapisovať do súboru %1.</translation>
    </message>
    </context>
<context>
    <name>MultisigAddressEntry</name>
    <message>
        <source>Form</source>
        <translation>Forma</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Zvoľte adresu z adresára</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Popis:</translation>
    </message>
</context>
<context>
    <name>MultisigDialog</name>
    <message>
        <source>Clear all</source>
        <translation>Zmazať všetko</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Vložiť adresu z klipbordu</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>MultisigInputEntry</name>
    <message>
        <source>Form</source>
        <translation>Forma</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>NetworkOptionsPage</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Možnosti</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Forma</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Zostatok:</translation>
    </message>
    <message>
        <source>Number of transactions:</source>
        <translation>Počet transakcií:</translation>
    </message>
    <message>
        <source>Unconfirmed:</source>
        <translation>Nepotvrdené:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Nedávne transakcie&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Your current balance</source>
        <translation>Váš súčasný zostatok</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Suma transakcií ktoré ešte neboli potvrdené a nezapočítavaju sa do celkového zostatku.</translation>
    </message>
    <message>
        <source>Total number of transactions in wallet</source>
        <translation>Celkový počet transakcií v peňaženke</translation>
    </message>
    </context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR kód</translation>
    </message>
    <message>
        <source>Request Payment</source>
        <translation>Vyžiadať platbu</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Suma:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Popis:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Správa:</translation>
    </message>
    <message>
        <source>&amp;Save As...</source>
        <translation>&amp;Uložiť ako...</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Poslať dominates</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Suma:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Poslať viacerým príjemcom naraz</translation>
    </message>
    <message>
        <source>Remove all transaction fields</source>
        <translation>Odobrať všetky políčka transakcie</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Zostatok:</translation>
    </message>
    <message>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Potvrďte odoslanie</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Odoslať</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopírovať sumu</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; do %2 (%3)</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Potvrdiť odoslanie dominates</translation>
    </message>
    <message>
        <source>Are you sure you want to send %1?</source>
        <translation>Ste si istí, že chcete odoslať %1?</translation>
    </message>
    <message>
        <source> and </source>
        <translation> a</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(bez popisu)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Form</source>
        <translation>Forma</translation>
    </message>
    <message>
        <source>A&amp;mount:</source>
        <translation>Su&amp;ma:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Zapla&amp;tiť:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Vložte popis pre túto adresu aby sa pridala do adresára</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Popis:</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Zvoľte adresu z adresára</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Vložiť adresu z klipbordu</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this recipient</source>
        <translation>Odstrániť tohto príjemcu</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Podpísať Správu</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Vložiť adresu z klipbordu</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/nepotvrdené</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 potvrdení</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dátum</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Suma</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, ešte nebola úspešne odoslaná</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>neznámy</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Detaily transakcie</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Táto časť obrazovky zobrazuje detailný popis transakcie</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Dátum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Hodnota</translation>
    </message>
    <message>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Nepotvrdené (%1 z %2 potvrdení)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Potvrdené (%1 potvrdení)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Ten blok nebol prijatý žiadnou inou nódou a pravdepodobne nebude akceptovaný!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Vypočítané ale neakceptované</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Prijaté s</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Prijaté od:</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Odoslané na</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Platba sebe samému</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Vyfárané</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Status transakcie. Pohybujte myšou nad týmto poľom a zjaví sa počet potvrdení.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Dátum a čas prijatia transakcie.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Typ transakcie.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Cieľová adresa transakcie.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Suma pridaná alebo odobraná k zostatku.</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Všetko</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Dnes</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Tento týždeň</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Tento mesiac</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Minulý mesiac</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Tento rok</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Rozsah...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Prijaté s</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Odoslané na</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Samému sebe</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Vyfárané</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Iné</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Vložte adresu alebo popis pre vyhľadávanie</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Min množstvo</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopírovať adresu</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopírovať popis</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopírovať sumu</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Editovať popis</translation>
    </message>
    <message>
        <source>Export Transaction Data</source>
        <translation>Exportovať transakčné dáta</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Čiarkou oddelovaný súbor (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potvrdené</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dátum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Popis</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Suma</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Chyba exportu</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Nedalo sa zapisovať do súboru %1.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Rozsah:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>do</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Sending...</source>
        <translation>Odosielanie...</translation>
    </message>
</context>
<context>
    <name>WindowOptionsPage</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Error: Transaction creation failed  </source>
        <translation>Chyba: Zlyhalo vytvorenie transakcie</translation>
    </message>
    <message>
        <source>Sending...</source>
        <translation>Odosielanie...</translation>
    </message>
    </context>
</TS>