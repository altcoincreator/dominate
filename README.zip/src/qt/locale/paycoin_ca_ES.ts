<TS language="ca_ES" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    </context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Address Book</source>
        <translation>llibreta d'adreces</translation>
    </message>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Feu doble clic per editar la direcció o l'etiqueta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Crear una nova adreça</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copieu l'adreça seleccionada al porta-retalls del sistema</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Borrar</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Direcció</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Encrypt wallet</source>
        <translation>Xifrar la cartera</translation>
    </message>
    </context>
<context>
    <name>BitcoinGUI</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Address</source>
        <translation>Direcció</translation>
    </message>
    </context>
<context>
    <name>DisplayOptionsPage</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Editar Adreça</translation>
    </message>
    </context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    </context>
<context>
    <name>MainOptionsPage</name>
    </context>
<context>
    <name>MintingTableModel</name>
    <message>
        <source>Address</source>
        <translation>Direcció</translation>
    </message>
    </context>
<context>
    <name>MintingView</name>
    <message>
        <source>Address</source>
        <translation>Direcció</translation>
    </message>
    </context>
<context>
    <name>MultisigAddressEntry</name>
    </context>
<context>
    <name>MultisigDialog</name>
    </context>
<context>
    <name>MultisigInputEntry</name>
    </context>
<context>
    <name>NetworkOptionsPage</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Balance:</source>
        <translation>Balanç:</translation>
    </message>
    <message>
        <source>Unconfirmed:</source>
        <translation>Sense confirmar:</translation>
    </message>
    <message>
        <source>Your current balance</source>
        <translation>El seu balanç actual</translation>
    </message>
    </context>
<context>
    <name>QRCodeDialog</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Enviar monedes</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balanç:</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Address</source>
        <translation>Direcció</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Direcció</translation>
    </message>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Sending...</source>
        <translation>L'enviament de ...</translation>
    </message>
</context>
<context>
    <name>WindowOptionsPage</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Sending...</source>
        <translation>L'enviament de ...</translation>
    </message>
    </context>
</TS>